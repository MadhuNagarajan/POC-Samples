﻿namespace XACES.Portal.WebAPI.Handlers
{
    public enum SchemeType
    {
        Basic,
        Token
    }
}